const EventSource = require('./src/EventSource')

module.exports = EventSource;